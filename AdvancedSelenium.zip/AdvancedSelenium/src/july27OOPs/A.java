package july27OOPs;

public class A {

	A(){
		
		System.out.println("Constructor of A");
	}
	A(String a){
	
		System.out.println("Parameterised constructor of A : " + a);
	}
	A(int a){
		
		System.out.println("Parameterised constructor of A for integer : " + a);
	}
	public void method1(){
		
		System.out.println("Method 1");
}

	public void method2(){
		
		System.out.println("Method 2");
	}
	
}
