package july27OOPs;

public class Class1 {

	
	public int add(int a, int b){
		return (a+b);
	}
}
