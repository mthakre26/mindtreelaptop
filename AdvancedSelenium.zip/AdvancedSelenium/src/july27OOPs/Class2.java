package july27OOPs;

public class Class2 extends Class1 {
	
	public int add(int a, int b){
		
		System.out.println(a + b);
		return (a+b);
	}

}
