package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginWithExample {

	WebDriver driver;

@Given("^User is at Login page page$")
public void user_is_at_Login_page_page() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
	driver = new ChromeDriver();
	
	driver.get("http://newtours.demoaut.com");
}

@When("^user enters UserNameName\"([^\"]*)\"$")
public void user_enters_UserNameName(String arg1) throws Throwable {
	 driver.findElement(By.name("userName")).sendKeys(arg1);
}

@When("^user enters passwordword\"([^\"]*)\"$")
public void user_enters_passwordword(String arg1) throws Throwable {
	driver.findElement(By.name("password")).sendKeys(arg1);
}

@When("^User clicks signin button$")
public void user_clicks_signin_button() throws Throwable {
	driver.findElement(By.name("login")).click();
}

@Then("^login is success and User is on the home pagepage\"([^\"]*)\"$")
public void login_is_success_and_User_is_on_the_home_pagepage(String arg1) throws Throwable {
	Assert.assertEquals("Find a Flight: Mercury Tours:", driver.getTitle());
}

}
