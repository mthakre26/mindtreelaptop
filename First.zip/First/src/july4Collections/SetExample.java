package july4Collections;

import java.util.HashSet;

public class SetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		HashSet<String> Obj= new HashSet<>();
		Obj.add("one");
		Obj.add ("two");
		Obj.add("Three");
		Obj.add("Two");
		Obj.add(null);
		System.out.println(Obj);
		System.out.println(Obj.size());
		
	}

}
