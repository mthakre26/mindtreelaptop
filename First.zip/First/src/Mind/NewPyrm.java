package Mind;

public class NewPyrm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		tophalf();
		bottomhalf();
	}
	
	public static void tophalf()
	{
		for (int line = 1; line <= 8; line++) {
			System.out.print("|");
		{
			
			for (int space = 1; space <= (line * -1 + 8); space++) 
			{
			System.out.print(space);
			}
			System.out.print("<>");
			for (int dot = 1; dot <= (line * 2 - 1); dot++) {
			System.out.print("*");
			}
			System.out.print("<>");
			for (int space = 1; space <= (line * -1 + 8); space++) {
			System.out.print(space);
			}	
			System.out.println("|");}
			}
	}		
		public static void bottomhalf()
			
		{
			for (int line = 8; line >= 1; line--) {
				System.out.print("|");
			{
				
				for (int space = 1; space <= (line * -1 + 8); space++) 
				{
				System.out.print(space);
				}
				System.out.print("<>");
				for (int dot = 1; dot <= (line * 2 - 1); dot++) {
				System.out.print("*");
				
				}
				System.out.print("<>");
				for (int space = 1; space <= (line * -1 + 8); space++) {
				System.out.print(space);
				}	
				System.out.println("|");}
				}
}

}
	


