package Mind;

public class ForexPyr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(){
			
			System.out.println("");
		}
	}

}
