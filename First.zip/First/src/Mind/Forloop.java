package Mind;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		for (int i = 0; i<= 5; i++){
			
			//System.out.print(i);
			
			for(int j = 0; j<=i; j++)
				
				//System.out.print(j);
			{	
		      System.out.print("*");
		
			}
		/*  i=0  j=0 out of inner loop
			  
    		i=1  j=0 
    		i=1 j=1 out of inner loop
    		
    		i=2 j=0
    		i=2 j=1
    		i=2 j=2 out of inner loop*/
            
    	/*  i=3 j=0
			i=3 j=1
			i=3 j=2
			i=3 j=3 out of inner loop*/
			//{
				//System.out.println(j);	
			//}
			
			System.out.println(" Out of inner loop");
		}
	}
}


