package Mind;

import java.util.Scanner;

public class RevreseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String rev = "";
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the String to reverse : ");
		String x = s.nextLine();
		
		for(int i=x.length()-1;i>=0;i--){
			
		String a = rev + x.charAt(i); 
		
		System.out.print(rev);
		System.out.print(a);
		}
		System.out.println();
	}

}
