package Mind;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner Rnum = new Scanner(System.in);
		System.out.println("Enter Number:");
	    int x = Rnum.nextInt();
	 	int rev = 0;
		
				 for(;x != 0; x =x/ 10)
				 {
					 
					 int i= x%10;
					 
					rev = rev * 10 + i;
			 		
		 	     }
		         System.out.print(rev);
			
			}		
}



