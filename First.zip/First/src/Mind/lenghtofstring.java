package Mind;

public class lenghtofstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int strLen = strLengthWithArray("Test Line");
	        System.out.println("Length of the String- " + strLen);
	        System.out.println("----------------------");
	        strLen = strLengthWithIndex("Test Line with index");
	        System.out.println("Length of the String- " + strLen);
	    }
	    
	    private static int strLengthWithArray(String str){
	        char[] charArr = str.toCharArray();
	        int count = 0;
	        for(char c : charArr){
	            count++;
	        }
	        return count;
	    }
	 
	    private static int strLengthWithIndex(String str){
	        int count = str.lastIndexOf("");
	        return count;
		
	}

}
