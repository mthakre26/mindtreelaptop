package Mind;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("website_Path")
		
		//To maximize browser
		
		driver.manage().window().maximize();
		
		//Title of the page
		
		System.out.println("Title of the page is " + driver.getTitle());
		
	}

}
