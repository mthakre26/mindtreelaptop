package Mind;

public class warmup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=30;
		int b=30;
		
		int sum = a + b;
		  // Double it if a and b are the same
		  if (a == b) {
			  sum= sum * 2;
		  }
		 
		  System.out.println(sum);
		}
		
	}

