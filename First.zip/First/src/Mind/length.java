package Mind;

public class length {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number=100;
		int length = String.valueOf(number).length();
		System.out.println(length);
		int j;
		{
		for (int i=length; i <=length; i++){
	 
			System.out.println(i);
			
			for(j=0; j<=i; j--);
	 
			
				System.out.print(j);
			}
		{
			System.out.println();
		}
		}
		}
		}	
	
		
 
    


