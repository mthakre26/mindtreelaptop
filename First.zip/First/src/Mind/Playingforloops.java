package Mind;

public class Playingforloops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//for(int count=1; count<=4; count++)
		for(int line=1; line<=5; line++)
		{
			for(int i =1; i<= (-1 * line+5) ; i++)
			{
			//System.out.print( -1 * count + 21 + " ");
			System.out.print(".");
		}
		System.out.print(line);
		
		for(int i=1; i<=(line-1); i++){
			
			System.out.print(".");
		}
		
		System.out.println();
	}
	}
}
