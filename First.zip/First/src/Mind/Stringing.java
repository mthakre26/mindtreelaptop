package Mind;

public class Stringing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str =" x";
			 //String back = str.substring(0);
			//  String front  = str.substring(str.length()-1);
			   /*String mid = str.substring(1, str.length()-1);
			    
			    System.out.println( str.charAt(str.length()) + mid);*/
		    
		   if(str.length()>=3 && str.substring(0,3).equals("not")){
			   System.out.println(str);
		     
		   }
		   System.out.println( "not " + str);
		 }
	}


