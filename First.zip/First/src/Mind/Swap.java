package Mind;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Before swapping");  
        int x=567;  
        int y=456;   
        System.out.println("After swapping");  
        x=x+y; 
        System.out.println(x); 
        y=x-y; 
        System.out.println(y);
        x=x-y;  
        System.out.println(x);
        System.out.println("value of x:"+x);  
        System.out.println("value of y:"+y);
	}

}
