package Mind;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 100;
		
		for(int range=1; range< 100; range++){
			
			int count = 0;
		for (int i=1; i<=range; i++)
		{
			if(range%i==0){
			count+= 1;
		}
		}
		if( count != 2 ){
			System.out.println(range +  " Numer is nt prime");
		}
		
		/*else 
		{
			System.out.println("Number is not prime");
		}*/
	}
		}	
	}
	
	

