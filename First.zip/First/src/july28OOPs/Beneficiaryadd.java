package july28OOPs;

public interface Beneficiaryadd {

	
	public abstract void add();
	public abstract void modify();
	public abstract void delete();
	
}
