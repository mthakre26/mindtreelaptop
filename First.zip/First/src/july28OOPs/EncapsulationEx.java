package july28OOPs;

public class EncapsulationEx {

	
	private String name;// class level within the class
	private int year;
	String color; //default access specifier that is whatever in the package is accessible for all the class
	
	
	/* public void display();
	{
		System.out.println("Name is : " + name);
	} */
	
	
	public void setName(String iname){
		
		name = iname;
	}
	public String getName(){
		
		return name;
	}
	public void setYear(int iyear){
		
		year=iyear; 
	}
	public int getYear(){
		
		return year;
	}
}
