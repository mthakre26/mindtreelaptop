package july28OOPs;

public class ThisEx {

		int date;
		int year;
		
		public void A(int date, int year){
			
			this.date = date;
			this.year = year;
		}
		public void showData(){
			   System.out.println("Value of A ="+ date);
			   System.out.println("Value of B ="+ year);
			 }
			 public static void main(String args[]){
			   ThisEx obj = new ThisEx();
			   obj.A(2,3);
			   obj.showData();
		
	}
}


