package july28OOPs;

public class ArrayEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] cities = {"Pune", "Mumbai", "Nagpur", "Aurg"};
		
		System.out.println(cities[1]);
		System.out.println(cities.length);
		
		cities[1] = "Delhi";
		
		System.out.println(cities[1]);
		
		for (int i = 0; i < cities.length; i++){
		System.out.println(cities[i]);
		}
		
		String[] names = new String[10];
		names[0] = "java";
		names[2] = "Python";
		for (int i = 0; i < names.length; i++)
		{
			System.out.println(names[i]);
		}
		
	}

}
