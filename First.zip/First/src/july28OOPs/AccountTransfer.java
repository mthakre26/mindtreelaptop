package july28OOPs;

public interface AccountTransfer extends Beneficiaryadd,Banking {

	public abstract void Neft();
	public abstract void Upi();
	public abstract void mobile();
	public abstract void Imps();
	public abstract void email();
}
