package july27OOPs;

public class Class1Class2Execution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Class2 c = new Class2();
		c.add(5, 10);
	}

}
