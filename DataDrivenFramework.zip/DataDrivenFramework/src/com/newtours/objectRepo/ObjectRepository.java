package com.newtours.objectRepo;

public class ObjectRepository {

	
	public static final String browser = "chrome";
	public static final String url = "http://newtours.demoaut.com/";
	public static final String sheet2 = "Sheet2";
	public static final int rowone = 1;
	
	
	
}
