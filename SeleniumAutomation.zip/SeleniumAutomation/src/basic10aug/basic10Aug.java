package basic10aug;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basic10Aug {

	public static void main(String[] args) {
		
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
				WebDriver  driver = new ChromeDriver();
				
				driver.get("https://www.google.co.in");
				driver.get("http://newtours.demoaut.com");
				driver.get("https://www.seleniumeasy.com");
				driver.manage().window().maximize();
				System.out.println(driver.getTitle());
				System.out.println(driver.getCurrentUrl());
				driver.close();
				//driver.quit();
			}

}
