package basic10aug;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumEasy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.seleniumeasy.com/test/basic-first-form-demo.html");
		
		driver.findElement(By.xpath("//input[@id='user-message']")).sendKeys("hkdwhfd");
		driver.findElement(By.xpath("//button[contains(text(),'Show Message')]")).click();
	    driver.findElement(By.xpath("//input[@id='sum1']")).sendKeys("10");
	    driver.findElement(By.xpath("//input[@id='sum2']")).sendKeys("10");
	    
	    driver.findElement(By.xpath("//button[contains(text(),'Get Total')]")).click();
	}

}
