package aug25;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePicker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		/*//driver.get("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
		
		driver.findElement(By.xpath("//span[@class='input-group-addon']")).click();
		driver.findElement(By.xpath("//table[@class='table-condensed']/tbody/tr[4]/td[4]")).click();*/
		driver.get("https://demoqa.com/datepicker/");
		driver.findElement(By.xpath("//input[@class ='hasDatepicker']")).click();
		String monthYear = driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		System.out.println(monthYear);
		
		while(!monthYear.equals("October 2020")){
			
			driver.findElement(By.xpath("//*[@class='ui-icon ui-icon-circle-triangle-e']")).click();
			monthYear = driver.findElement(By.xpath("//*[@class ='ui-datepicker-title']")).getText();
		}
		if(monthYear.equals("October 2020")) {
			
			driver.findElement(By.xpath("//*[@class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all']/table/tbody/tr[2]/td[5]")).click();
		}
		
	}

}
