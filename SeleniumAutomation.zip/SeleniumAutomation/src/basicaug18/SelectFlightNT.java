package basicaug18;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelectFlightNT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com/");
		
		//System.out.println(driver.getTitle());
		//System.out.println(driver.getCurrentUrl());
		
		driver.findElement(By.name("userName")).sendKeys("Batman");
		driver.findElement(By.name("password")).sendKeys("batman");
		driver.findElement(By.name("login")).click();
		
		List<WebElement> list = driver.findElements(By.name("tripType"));
		
	//	list.get(1).click();
		
		for(WebElement radio : list){
			
			String trip = radio.getAttribute("value");
			if (trip.equals("oneway")){
				radio.click();
			}
			
			
		}
		
	}

}
