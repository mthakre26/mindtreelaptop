package basicaug18;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumEasyPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.seleniumeasy.com/test/jquery-dropdown-search-demo.html");
		driver.manage().window().maximize();
		driver.manage().window().maximize();
		List<WebElement> drp  = driver.findElements(By.xpath("//span[@class='select2-selection__arrow']"));
		
		drp.get(0).click();
		
		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[4]")).click();
		
		driver.findElement(By.xpath("//input[@class='select2-search__field']")).click();
		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[2]")).click();
		driver.findElement(By.xpath("//input[@class='select2-search__field']")).click();
		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[4]")).click();
		driver.findElement(By.xpath("//input[@class='select2-search__field']")).click();
		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[6]")).click();
		
		//driver.findElement(By.xpath("//span[@class='select2-selection__arrow']")).click();
		List<WebElement> drp1 = driver.findElements(By.xpath("//span[@class='select2-selection__rendered']"));
		drp1.get(1).click();
		
		driver.findElement(By.xpath("//ul[@class='select2-results__options']/li[3]")).click();
		System.out.println(drp);
	
		WebElement drp3 = driver.findElement(By.name("files"));
		
		Select d = new Select(drp3);
		d.selectByIndex(0);
		
	}

}
