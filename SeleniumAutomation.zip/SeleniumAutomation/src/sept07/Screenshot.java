package sept07;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Screenshot {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com/");
		
		TakesScreenshot ss = (TakesScreenshot)driver;
		
		File scr = ss.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scr, new File("Screenshot.jpg"));
	}

}
