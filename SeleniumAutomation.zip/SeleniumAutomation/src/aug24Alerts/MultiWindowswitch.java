package aug24Alerts;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultiWindowswitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.seleniumeasy.com/test/window-popup-modal-");
		
		driver.manage().window().maximize();
		driver.findElement(By.xpath(".//*[@Title ='Twitter']")).click();
		String parentWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(parentWindowHandle);
		driver.findElement(By.xpath(".//*[@Title='Facebook']")).click();
		//String parentWindowHandle = driver.getWindowHandle();
		System.out.println(parentWindowHandle);
		Set<String> allWindows = driver.getWindowHandles();
		System.out.println(allWindows);
		
		for(String window : allWindows){
			if(! window.equals(parentWindowHandle)){
				if(driver.getCurrentUrl().contains("twitter")){
					
					driver.findElement(By.id("username_or_email")).sendKeys("7693249243");
				}
				
				
			}
			
		}
		driver.switchTo().window(parentWindowHandle);
		//driver.quit();
	}

}
