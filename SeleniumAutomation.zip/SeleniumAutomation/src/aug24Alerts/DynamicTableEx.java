package aug24Alerts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicTableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("Batman");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("batman");
		driver.findElement(By.xpath("//input[@name='login']")).click();
		
		driver.findElement(By.xpath("//input[@name='findFlights']")).click();
		
		List<WebElement>  rows= driver.findElements(By.xpath("//form[@name='results']/table/tbody/tr"));
		
		for(WebElement row: rows){
			
			List<WebElement> cells = row.findElements(By.tagName("td"));
			
			for(int i = 0; i < cells.size(); i++){
				
				if(cells.get(i).getText().equals("Pangaea Airlines 362")){
					
					cells.get(i-1).click();
				}				
			}			
		}		
	}
}
