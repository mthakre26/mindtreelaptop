package testScript;

import java.util.ArrayList;
import java.util.HashMap;

import library.KeywordLibrary;
import utilities.Excel;

public class TC001 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		HashMap<Integer, ArrayList<String>> testCases = Excel.getTestCaseData();
		for(Integer key: testCases.keySet()) {
			ArrayList<String> testData = testCases.get(key);
			if(testData.get(1).equals("run")) {
				HashMap<Integer, ArrayList<String>> map = Excel.getAllData(testData.get(0));
				for (Integer key1 : map.keySet()) {
					ArrayList<String> list = map.get(key1);
					try {
						KeywordLibrary.controller(list.get(0), list.get(1), list.get(2), list.get(3));
						Excel.updateResult(testData.get(0), key1, "pass");
					} catch (Exception e) {
						Excel.updateResult(testData.get(0), key1, "fail");
						e.printStackTrace();
					}
				}
			} else {
				System.out.println("Skipping test: " + testData.get(0));
			}
		}
	}
}
